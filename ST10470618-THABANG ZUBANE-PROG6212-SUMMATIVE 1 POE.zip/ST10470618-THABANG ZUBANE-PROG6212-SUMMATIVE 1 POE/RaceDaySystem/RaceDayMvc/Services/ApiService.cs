﻿using System.Net.Http.Json;

namespace RaceDayMvc.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            // Set the base address for the API Url
            _httpClient.BaseAddress = new Uri("https://localhost:7280/api/");
        }

        public async Task<List<EventViewModel>?> GetEventsAsync()
        {
            try
            {
                var events = await _httpClient.GetFromJsonAsync<List<EventViewModel>>("eventsvenues/events");
                return events ?? new List<EventViewModel>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching events: {ex.Message}");
                return new List<EventViewModel>();
            }
        }

        public async Task<List<VenueViewModel>?> GetVenuesAsync()
        {
            return await _httpClient.GetFromJsonAsync<List<VenueViewModel>>("eventsvenues/venues");
        }
    }

    // View Models for mapping data from API
    public class EventViewModel
    {
        public int EventId { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string? Description { get; set; }
        public string EventType { get; set; } = "Run";
        public string Status { get; set; } = "Upcoming";
        public string VenueName { get; set; } = "Unknown";
        public string OrganiserName { get; set; } = "Unknown";
    }

    public class VenueViewModel
    {
        public int VenueId { get; set; }
        public string VenueName { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string Province { get; set; } = string.Empty;
        public int Capacity { get; set; }
    }
}
