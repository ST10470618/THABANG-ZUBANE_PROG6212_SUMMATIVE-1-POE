using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Services;

namespace RaceDayMvc.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApiService _apiService;

        public HomeController(ApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            var events = await _apiService.GetEventsAsync();
            return View(events ?? new List<EventViewModel>());
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}
