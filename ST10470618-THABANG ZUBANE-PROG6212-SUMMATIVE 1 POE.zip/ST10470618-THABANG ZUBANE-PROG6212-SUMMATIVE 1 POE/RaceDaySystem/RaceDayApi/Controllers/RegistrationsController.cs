﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Models;

namespace RaceDayApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RegistrationsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public RegistrationsController(RaceDayDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> CreateRegistration([FromBody] RegistrationDto dto)
        {
            var participant = await _context.Users.FindAsync(dto.ParticipantId);
            if (participant == null || participant.GetRole() != "Participant")
            {
                return BadRequest(new { message = "Invalid Participant ID" });
            }

            var category = await _context.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryId == dto.CategoryId);

            if (category == null)
            {
                return BadRequest(new { message = "Inalid Category ID." });
            }

            var existingReg = await _context.Registrations
                .FirstOrDefaultAsync(r => r.ParticipantId == dto.ParticipantId && r.CategoryId == dto.CategoryId);

            if (existingReg != null)
            {
                return Conflict(new { message = "Participant is already registered for this category." });
            }

            var registration = new Registration
            {
                ParticipantId = dto.ParticipantId,
                CategoryId = dto.CategoryId,
                RegistrationStatus = "Pending",
                RaceNumber = new Random().Next(1000, 9999)
            };

            _context.Registrations.Add(registration);
            await _context.SaveChangesAsync(); // FIX: Await the async call

            var payment = new Payment
            {
                RegistrationId = registration.RegistrationId,
                Amount = category.EntryFee,
                PaymentStatus = "Pending"
            };

            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            return StatusCode(201, new
            {
                message = "Registration created successfully. Payment pending.",
                registrationId = registration.RegistrationId,
                raceNumber = registration.RaceNumber,
                amountDue = category.EntryFee,
            });
        }

        ICollection<object> GetUserRegistrations(int userId)
        {
            return new List<object>();
        }

        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetRegistrationsByUser(int userId)
        {
            var registrations = await _context.Registrations
                .Where(r => r.ParticipantId == userId)
                .Include(r => r.Category)
                .ThenInclude(c => c!.Event)
                .Include(r => r.Payment)
                .Include(r => r.Results)
                .Select(r => new
                {
                    r.RegistrationId,
                    r.RegistrationDate,
                    r.RegistrationStatus,
                    r.RaceNumber,
                    CategoryName = r.Category != null ? r.Category.CategoryName : "Unknown",
                    EventName = r.Category != null && r.Category.Event != null ? r.Category.Event.EventName : "Unknown",
                    PaymentStatus = r.Payment != null ? r.Payment.PaymentStatus : "No Payment",
                    PaymentAmount = r.Payment != null ? r.Payment.Amount : 0,
                    Result = r.Results != null ? new { r.Results.FinishTime, r.Results.Position, r.Results.ResultStatus } : null,
                })
                .ToListAsync();

            return Ok(registrations);
        }

        [HttpPost("pay/{registrationId}")]
        public async Task<IActionResult> MakePayment(int registrationId, [FromBody] PaymentDto dto)
        {
            var payment = await _context.Payments
                .Include(p => p.Registration)
                .FirstOrDefaultAsync(p => p.RegistrationId == registrationId);

            if (payment == null)
            {
                return NotFound(new { message = "Payment record not found for this registration." });
            }

            payment.PaymentStatus = "Paid";
            payment.PaymentDate = DateTime.UtcNow;
            payment.PaymentReference = dto.PaymentReference ?? $"REF-{Guid.NewGuid().ToString().Substring(0, 8).ToUpper()}";

            if (payment.Registration != null)
            {
                payment.Registration.RegistrationStatus = "Confirmed";
            }

            await _context.SaveChangesAsync();
            return Ok(new { message = "Payment successful! Registration confirmed.", reference = payment.PaymentReference });
        }

        [HttpPost("results")]
        public async Task<IActionResult> RecordResult([FromBody] ResultDto dto)
        {
            var registration = await _context.Registrations.FindAsync(dto.RegistrationId);
            if (registration == null)
            {
                return NotFound(new { message = "Registration ID not found" });
            }

            var existingResult = await _context.Results.FirstOrDefaultAsync(r =>  r.RegistrationId == dto.RegistrationId);
            if (existingResult != null)
            {
                existingResult.FinishTime = dto.FinishTime;
                existingResult.Position = dto.Position;
                existingResult.ResultStatus = dto.ResultStatus;
            }
            else
            {
                var result = new Result
                {
                    RegistrationId = dto.RegistrationId,
                    FinishTime = dto.FinishTime,
                    Position = dto.Position,
                    ResultStatus = dto.ResultStatus,
                };
                _context.Results.Add(result);
            }

            await _context.SaveChangesAsync();

            return Ok(new { message = "Race result recorded successfully." });
        }
    }
    public class RegistrationDto
    {
        public int ParticipantId { get; set; }
        public int CategoryId { get; set; }
    }
    public class PaymentDto
    {
        public string? PaymentReference { get; set; }
    }
    public class ResultDto
    {
        public int RegistrationId { get; set; }
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string ResultStatus { get; set; } = "Finished";
    }
}
