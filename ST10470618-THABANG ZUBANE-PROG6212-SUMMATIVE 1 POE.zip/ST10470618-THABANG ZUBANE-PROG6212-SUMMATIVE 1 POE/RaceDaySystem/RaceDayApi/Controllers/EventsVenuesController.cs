﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Models;

namespace RaceDayApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventsVenuesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EventsVenuesController(RaceDayDbContext context)
        {
            _context = context;
        }

        [HttpGet("venues")]
        public async Task<IActionResult> GetVenues()
        {
            var venues = await _context.Venues.ToListAsync();
            return Ok(venues);
        }

        [HttpPost("venues")]
        public async Task<IActionResult> CreateVenue([FromBody] Venue venue)
        {
            _context.Venues.Add(venue);
            await _context.SaveChangesAsync();
            return StatusCode(201, new { message = "Venue created successfully", venueId = venue.VenueId });
        }

        [HttpGet("events")]
        public async Task<IActionResult> GetEvents()
        {
            try
            {
                var events = await _context.Events.ToListAsync();
                return Ok(events);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching events.", details = ex.Message });
            }

        }

        [HttpPost("events")]
        public async Task<IActionResult> CreateEvent([FromBody] CreateEventDto dto)
        {
            var organiser = await _context.Users.FindAsync(dto.OrganiserId);
            if (organiser == null || organiser.GetRole() != "Event Organiser")
            {
                return BadRequest(new { message = "Invalid Organiser ID " });
            }

            var venue = await _context.Venues.FindAsync(dto.VenueId);
            if (venue == null)
            {
                return BadRequest(new { message = "Invalid Venue ID." });
            }

            var newEvent = new Event
            {
                EventName = dto.EventName,
                EventDate = dto.EventDate,
                Description = dto.Description,
                EventType = dto.EventType,
                OrganiserId = dto.OrganiserId,
                VenueId = dto.VenueId,
                status = "Upcoming"
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            return StatusCode(201, new { message = "Event created successfully", eventId = newEvent.EventId });
        }

        [HttpPost("categories")]
        public async Task<IActionResult> AddCategory([FromBody] Category category)
        {
            var eventExits = await _context.Events.AnyAsync(e => e.EventId == category.EventId);
            if (!eventExits)
            {
                return BadRequest(new { message = "Associated Event ID does not exist." });
            }

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return StatusCode(201, new { message = "Category added successfully", categoryId = category.CategoryId });
        }
    }

    public class CreateEventDto
    {
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string? Description { get; set; }
        public string EventType { get; set; } = "Run";
        public string OrganiserId { get; set; } = string.Empty;
        public int VenueId { get; set; }
    }
}
